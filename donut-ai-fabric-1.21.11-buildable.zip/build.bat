@echo off
setlocal
title Donut AI - Fabric 1.21.11 Builder

echo ==========================================
echo   Donut AI - Minecraft 1.21.11 Builder
echo ==========================================
echo.

where java >nul 2>nul
if errorlevel 1 (
    echo ERROR: Java was not found.
    echo Install Java 21, then run build.bat again.
    echo.
    pause
    exit /b 1
)

java -version
echo.

if not exist "gradlew.bat" (
    echo ERROR: gradlew.bat is missing.
    echo Make sure you extracted the COMPLETE project ZIP.
    echo.
    pause
    exit /b 1
)

echo Building mod... This may take a few minutes the first time.
echo.

call gradlew.bat build --stacktrace
if errorlevel 1 (
    echo.
    echo ==========================================
    echo BUILD FAILED
    echo ==========================================
    echo.
    echo If this is a dependency/download error, check your internet
    echo connection and run build.bat again.
    echo.
    pause
    exit /b 1
)

echo.
echo ==========================================
echo BUILD SUCCESSFUL!
echo ==========================================
echo.
echo Your mod JAR files are in:
echo build\libs
echo.
echo The production JAR is the shortest-named JAR there.
echo Copy it into:
echo %%APPDATA%%\.minecraft\mods
echo.
pause

# Donut AI Helper — Fabric 1.21.11

This is an original client-side starter implementation. It is not the private source code of the YouTube creator.

## Build
1. Install Java 21.
2. Extract this project to a simple folder such as `C:\Projects\donut-ai`.
3. Double-click `build.bat`.
4. The first build may take several minutes because Gradle downloads Minecraft/Fabric dependencies.
5. After a successful build, open `build\libs`.
6. Put the shortest-named production JAR into `%APPDATA%\.minecraft\mods`.

Fabric's current documentation recommends `net.fabricmc.fabric-loom-remap` for obfuscated Minecraft 1.21.11 and older, and the standard Windows build command is `gradlew.bat build`.

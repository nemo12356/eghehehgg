package com.example.donutai;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public class DonutAiClient implements ClientModInitializer {
    private static boolean enabled;
    private static KeyMapping toggleKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.donutai.toggle",
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.donutai"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.consumeClick()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.displayClientMessage(
                            Component.literal("Donut AI Helper: " + (enabled ? "ON" : "OFF")),
                            true
                    );
                }
            }
        });
    }

    public static boolean isEnabled() {
        return enabled;
    }

    public static Minecraft client() {
        return Minecraft.getInstance();
    }
}
